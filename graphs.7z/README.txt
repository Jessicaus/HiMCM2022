0:linear
1:polynomial
2:logarithmic
3:exponential